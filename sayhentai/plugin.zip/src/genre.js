function execute() {
    return Response.success([
        {
            "input": "https://sayhentai.ink/genre/18/",
            "title": "18+",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/3d/",
            "title": "3D",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/action/",
            "title": "Action",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/adult/",
            "title": "Adult",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/bao-dam/",
            "title": "Bạo Dâm",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/choi-hai-lo/",
            "title": "Chơi hai lỗ",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/comedy/",
            "title": "Comedy",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/detective/",
            "title": "Detective",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/doujinshi/",
            "title": "Doujinshi",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/drama/",
            "title": "Drama",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/ecchi/",
            "title": "Ecchi",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/fantasy/",
            "title": "Fantasy",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/gangbang/",
            "title": "Gangbang",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/gender-bender/",
            "title": "Gender Bender",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/giao-vien/",
            "title": "Giáo viên",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/group/",
            "title": "Group",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/ham-hiep/",
            "title": "Hãm hiếp",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/harem/",
            "title": "Harem",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/hau-mon/",
            "title": "Hậu môn",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/historical/",
            "title": "Historical",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/horror/",
            "title": "Horror",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/housewife/",
            "title": "Housewife",
            "script": "gen.js"
        },
      {
            "input": "https://sayhentai.ink/genre/Josei/",
            "title": "Josei",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/khong-che/",
            "title": "Không che",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/kinh-di/",
            "title": "Kinh dị",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/lao-gia-dam/",
            "title": "Lão già dâm",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/loan-luan/",
            "title": "Loạn luân",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/loli/",
            "title": "Loli",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/manga/",
            "title": "manga",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/manhua/",
            "title": "Manhua",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/manhwa/",
            "title": "Manhwa",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/martisl-arts/",
            "title": "Martial arts",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/mature/",
            "title": "Mature",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/milf/",
            "title": "Milf",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/mind-break/",
            "title": "Mind break",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/nguc-lon/",
            "title": "Ngực lớn",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/nguc-nho/",
            "title": "Ngực nhỏ",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/no-le/",
            "title": "Nô lệ",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/ntr/",
            "title": "NTR",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/nu-sinh/",
            "title": "Nữ Sinh",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/old-man/",
            "title": "Old Man",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/one-shot/",
            "title": "One shot",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/oneshot/",
            "title": "Oneshot",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/psychological/",
            "title": "Psychological",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/rape/",
            "title": "Rape",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/romance/",
            "title": "Romance",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/school-life/",
            "title": "School life",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/sci-fi/",
            "title": "Sci-fi",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/seinen/",
            "title": "Seinen",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/series/",
            "title": "Series",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/shoujo/",
            "title": "Shoujo",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/shoujo-ai/",
            "title": "Shoujo AI",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/shounen/",
            "title": "Sports",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/slice-of-life/",
            "title": "Slice of life",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/smut/",
            "title": "Smut",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/sports/",
            "title": "Sports",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/supernatural/",
            "title": "Supernatural",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/tragedy/",
            "title": "Tragedy",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/virgin/",
            "title": "Virgin",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/webtoon/",
            "title": "Webtoon",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/y-ta/",
            "title": "Y tá",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/yaoi/",
            "title": "Yaoi",
            "script": "gen.js"
        },
        {
            "input": "https://sayhentai.ink/genre/yuri/",
            "title": "Yuri",
            "script": "gen.js"
        }
          
    ]);
}